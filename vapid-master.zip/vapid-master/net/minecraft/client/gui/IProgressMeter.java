package net.minecraft.client.gui;

public interface IProgressMeter
{
    String[] field_146510_b_ = new String[] {"oooooo", "Oooooo", "oOoooo", "ooOooo", "oooOoo", "ooooOo", "oooooO"};

    void func_146509_g();
}
